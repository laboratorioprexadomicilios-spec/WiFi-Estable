package com.wifiestable;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status, wifi, internet, ping, rssi, cuts;
    private Button toggle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        wifi = findViewById(R.id.wifi);
        internet = findViewById(R.id.internet);
        ping = findViewById(R.id.ping);
        rssi = findViewById(R.id.rssi);
        cuts = findViewById(R.id.cuts);
        toggle = findViewById(R.id.toggle);

        if (android.os.Build.VERSION.SDK_INT >= 33) {
            java.util.ArrayList<String> permissions = new java.util.ArrayList<>();
            if (checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES);
            }
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS);
            }
            if (!permissions.isEmpty()) {
                requestPermissions(permissions.toArray(new String[0]), 100);
            }
        }

        toggle.setOnClickListener(v -> {
            Intent i = new Intent(this, StabilityService.class);
            if (!StabilityService.running) {
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                else startService(i);
            } else {
                stopService(i);
            }
        });

        android.os.Handler h = new android.os.Handler();
        Runnable r = new Runnable() {
            @Override public void run() {
                status.setText(StabilityService.running ? "🟢 MÁXIMA ESTABILIDAD ACTIVA" : "⚪ DESACTIVADO");
                toggle.setText(StabilityService.running ? "DESACTIVAR" : "ACTIVAR MÁXIMA ESTABILIDAD");
                wifi.setText("📶 Wi‑Fi: " + StabilityService.wifiState);
                internet.setText("🌐 Internet: " + StabilityService.internetState);
                ping.setText("📡 Latencia: " + StabilityService.lastPingMs + " ms");
                rssi.setText("📶 Señal: " + StabilityService.lastRssi + " dBm");
                cuts.setText("🔄 Microcortes: " + StabilityService.cuts);
                h.postDelayed(this, 1000);
            }
        };
        h.post(r);
    }
}
