package com.wifiestable;

import android.app.*;
import android.content.*;
import android.net.*;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class StabilityService extends Service {
    public static volatile boolean running = false;
    public static volatile String wifiState = "—";
    public static volatile String internetState = "—";
    public static volatile long lastPingMs = 0;
    public static volatile int lastRssi = 0;
    public static volatile int cuts = 0;

    private ConnectivityManager cm;
    private WifiManager wm;
    private WifiManager.WifiLock wifiLock;
    private Handler handler;
    private Runnable monitor;
    private boolean lastInternet = true;

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        wm = (WifiManager)getApplicationContext().getSystemService(WIFI_SERVICE);

        NotificationChannel ch = new NotificationChannel("wifi_stable", "WiFi Estable",
                NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);

        Notification n = new Notification.Builder(this, "wifi_stable")
                .setContentTitle("WiFi Estable activo")
                .setContentText("Vigilando estabilidad de la conexión")
                .setSmallIcon(android.R.drawable.stat_sys_wifi)
                .setOngoing(true)
                .build();

        startForeground(77, n);

        try {
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "WiFiEstableLock");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception ignored) {}

        handler = new Handler(Looper.getMainLooper());
        monitor = () -> {
            checkConnection();
            handler.postDelayed(monitor, 3000);
        };
        handler.post(monitor);
    }

    private void checkConnection() {
        try {
            WifiInfo info = wm.getConnectionInfo();
            boolean connected = info != null && info.getNetworkId() != -1;
            wifiState = connected ? "CONECTADO" : "DESCONECTADO";
            if (connected) lastRssi = info.getRssi();

            ConnectivityManager.Network network = cm.getActiveNetwork();
            NetworkCapabilities caps = network == null ? null : cm.getNetworkCapabilities(network);
            boolean validated = caps != null &&
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
                    caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);

            internetState = validated ? "ESTABLE" : "SIN VALIDAR / CORTADA";

            if (lastInternet && !validated) cuts++;
            lastInternet = validated;

            if (validated) {
                long t = System.currentTimeMillis();
                HttpURLConnection c = (HttpURLConnection)new URL("https://connectivitycheck.gstatic.com/generate_204").openConnection();
                c.setConnectTimeout(1500);
                c.setReadTimeout(1500);
                c.setUseCaches(false);
                c.connect();
                c.getResponseCode();
                lastPingMs = System.currentTimeMillis() - t;
                c.disconnect();
            }
        } catch (Exception e) {
            internetState = "SIN RESPUESTA";
            if (lastInternet) cuts++;
            lastInternet = false;
        }
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        if (handler != null && monitor != null) handler.removeCallbacks(monitor);
        try { if (wifiLock != null && wifiLock.isHeld()) wifiLock.release(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
