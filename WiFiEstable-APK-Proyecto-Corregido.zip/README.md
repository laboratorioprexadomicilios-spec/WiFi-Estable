# WiFi Estable - proyecto Android corregido

Correcciones principales:
- El workflow de GitHub Actions instala explícitamente Gradle 8.9, compatible con Android Gradle Plugin 8.7.x.
- Se actualizó setup-java.
- Se eliminó AppCompat innecesario.
- WebView implementa correctamente el selector de archivos de Android, para que los botones de elegir imagen puedan abrir la galería/archivos.
- Se mantiene el HTML original dentro de `app/src/main/assets/index.html`.

Para generar el APK:
GitHub -> Acciones/Actions -> Generar APK WiFi Estable -> ejecutar workflow.
El APK queda como artefacto `WiFi-Estable-APK`.
