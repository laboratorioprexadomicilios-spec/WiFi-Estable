# WiFi estable — APK

Proyecto Android que envuelve la versión corregida de la aplicación HTML en un WebView.

## Compilación automática
Al subir este proyecto a GitHub, GitHub Actions compila automáticamente el APK de depuración.

Archivo generado:
`app/build/outputs/apk/debug/app-debug.apk`

La acción también deja el APK disponible como artefacto descargable.
